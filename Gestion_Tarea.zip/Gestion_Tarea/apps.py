from django.apps import AppConfig


class GestionTareaConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'Gestion_Tarea'
